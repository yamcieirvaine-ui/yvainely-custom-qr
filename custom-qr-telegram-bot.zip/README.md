# Custom QR Telegram Bot

A Telegram bot that receives a payment QR image, asks for a display name, offers four designs, and returns a composed image.

## 1. Create the bot
Open Telegram and message @BotFather:
- `/newbot`
- choose a name
- choose a username
- copy the bot token

## 2. Deploy
Deploy this folder to Vercel.

Add environment variable:
`BOT_TOKEN=your_bot_token`

## 3. Set the webhook
After deployment, open this URL in a browser:

`https://api.telegram.org/botYOUR_TOKEN/setWebhook?url=https://YOUR-DOMAIN.vercel.app/api/telegram`

Telegram should return `{"ok":true,...}`.

## 4. Use
Open your bot:
`/start`
Send QR image -> send name -> choose design.

## Notes
- The uploaded QR is placed unchanged inside the generated design.
- Always test-scan the final image with the actual banking app before using it.
- This starter uses in-memory sessions. For a large public bot, use Redis/Upstash for persistent sessions and rate limits.
